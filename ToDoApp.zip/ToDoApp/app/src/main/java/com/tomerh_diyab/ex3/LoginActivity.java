package com.tomerh_diyab.ex3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String MY_DB_NAME = "TodosDB.db";

    public static SQLiteDatabase TodosDB = null;
    private EditText username, password;
    private Button loginBtn;

    SharedPreferences sp;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

            try {
                TodosDB = openOrCreateDatabase(MY_DB_NAME, MODE_PRIVATE, null);

                String usersTable = "CREATE TABLE IF NOT EXISTS users(username VARCHAR primary key, password VARCHAR);";
                TodosDB.execSQL(usersTable);
                String todosTable = "CREATE TABLE IF NOT EXISTS todos(_id INT primary key, username VARCHAR, title VARCHAR, description VARCHAR, datetime INTEGER);";
                //String todosTable = "DROP TABLE IF EXISTS todos";
                TodosDB.execSQL(todosTable);

            } catch (Exception e) {

            }



        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginButton);

        loginBtn.setOnClickListener(this);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Toolbar actionBar = findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuItem about = menu.add("About");

        about.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                dialog();
                return true;
            }
        });
        return true;
    }

    private void dialog(){
        AlertDialog.Builder myDialog = new AlertDialog.Builder(this);
        myDialog.setTitle("ToDoApp, " + getPackageName());
        myDialog.setMessage("Tomer Haliva, 18/5/2021");
        myDialog.setCancelable(false);
        myDialog.setNegativeButton("Back", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) { }
        });
        myDialog.show();
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, ToDoListActivity.class);

        String usernameInput = username.getText().toString();
        String passwordInput = password.getText().toString();

        if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
            Toast.makeText(this, "One or more fields are empty", Toast.LENGTH_SHORT).show();

        } else {
            if (checkIfExists(usernameInput) == false){
                addUser(usernameInput, passwordInput);
                intent.putExtra("CURRENT_USER", usernameInput);
                startActivity(intent);
            }

            else{
                if(checkPassword(usernameInput, passwordInput) == false)
                    Toast.makeText(this, "Wrong Password", Toast.LENGTH_SHORT).show();
                else{
                    intent.putExtra("CURRENT_USER", usernameInput);
                    startActivity(intent);
                }
            }
        }
    }

    public boolean checkIfExists(String usernameInput) {
        String sql = "SELECT * FROM users";
        Cursor cursor = TodosDB.rawQuery(sql, null);
        int nameId = cursor.getColumnIndex("username");


        if (cursor.moveToFirst()) {
            do {
                // Get the results and store them in a String
                String nameFromDB = cursor.getString(nameId);

                if (nameFromDB.equals(usernameInput))
                    return true;

                // Keep getting results as long as they exist
            } while (cursor.moveToNext());
        }
        return false;
    }



    public void addUser(String usernameInput, String passwordInput){
        String sql = "INSERT INTO users (username, password) VALUES ('" + usernameInput + "', '" + passwordInput + "');";
        TodosDB.execSQL(sql);
       // editor.putString("username", usernameInput);
       // editor.commit();
    }

    public boolean checkPassword(String usernameInput, String passwordInput){
        String sql = "SELECT * FROM users";

        Cursor cursor = TodosDB.rawQuery(sql, null);
        cursor.moveToFirst();

        int IdName = cursor.getColumnIndex("username");
        int IdPassword = cursor.getColumnIndex("password");

        if (cursor.moveToFirst()) {
            do {
                // Get the results and store them in a String
                String nameFromDB = cursor.getString(IdName);
                String passwordFromDB = cursor.getString(IdPassword);
                if (nameFromDB.equals(usernameInput))
                    if(passwordFromDB.equals(passwordInput))
                        return true;

                // Keep getting results as long as they exist
            } while (cursor.moveToNext());
        }
        return false;
    }
}