package com.tomerh_diyab.ex3;

public class TodoItem {

    private String title;

    private String description;

    private String date;

    private String time;

    private String username;

    private int id;


    public TodoItem(String title, String description, String date, String time, String username, int id){
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.username = username;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getUsername(){
        return username;
    }

    public int getId(){
        return id;
    }

    public String toString(){

        return title + ", " + description + ", " + date + ", " + time;
    }
}
