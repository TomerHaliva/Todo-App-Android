package com.tomerh_diyab.ex3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ViewFlipper;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ToDoListActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences sp;
    SharedPreferences.Editor editor;
    SQLiteDatabase TodosDB = LoginActivity.TodosDB;
    private FloatingActionButton addButton;
    protected static ListView listView;
    protected static TodoAdapter arrayAdapter;
    protected static ArrayList<TodoItem> arrayList;
    private ViewFlipper viewsFlipper;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do_list);


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Toolbar actionBar = findViewById(R.id.actionBar);
        actionBar.setTitle("Todo List (" +  getIntent().getStringExtra("CURRENT_USER") + ")");
        setSupportActionBar(actionBar);

        sp = getSharedPreferences("TodoPref", Context.MODE_PRIVATE);
        editor = sp.edit();
        editor.putString("loggedUser", getIntent().getStringExtra("CURRENT_USER"));
        editor.apply();


        searchView = findViewById(R.id.Search);

        addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(this);

        listView = findViewById(R.id.List);
        arrayList = loadListFromDB();
        arrayAdapter = new TodoAdapter(this, arrayList);

        listView.setAdapter(arrayAdapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int itemId = arrayList.get(position).getId();
                String itemTitle = arrayList.get(position).getTitle();
                String itemDescription = arrayList.get(position).getDescription();
                String itemDate = arrayList.get(position).getDate();
                String itemTime = arrayList.get(position).getTime();

                moveOn(itemId, itemTitle, itemDescription, itemDate, itemTime);
            }
        });


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ToDoListActivity.this);
                builder.setTitle("Are you sure you want to delete this item?");
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    String deleteQuery = "DELETE FROM todos WHERE _id = " +arrayList.get(position).getId();
                    TodosDB.execSQL(deleteQuery);
                    arrayList.remove(position);
                    arrayAdapter.notifyDataSetChanged();

                    }
                });
                builder.show();

                return true;
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<TodoItem> filteredList = new ArrayList<TodoItem>();

                for(TodoItem item : arrayList){
                    if(item.getTitle().contains(newText) || item.getDescription().contains(newText))
                        filteredList.add(item);
                }

                TodoAdapter adapter = new TodoAdapter(ToDoListActivity.this, filteredList);
                listView.setAdapter(adapter);
                return true;
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                logout();
                return false;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_menu, menu);
        return true;
    }

    private void logout(){
        editor.clear();
        editor.apply();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);

    }


    @Override
    public void onClick(View v) {

        Intent intent = new Intent(this, EditorActivity.class);
        String currentUser = getIntent().getStringExtra("CURRENT_USER");
        intent.putExtra("CURRENT_USER", currentUser);
        intent.putExtra("FLAG", "addScreen");

        startActivity(intent);
    }

    private ArrayList<TodoItem> loadListFromDB(){

        ArrayList<TodoItem> resultsList = new ArrayList<TodoItem>();
        String sql = "SELECT * FROM todos";
        Cursor cursor = TodosDB.rawQuery(sql,null);
        int rowId = cursor.getColumnIndex("_id");
        int nameId = cursor.getColumnIndex("username");
        int titleId = cursor.getColumnIndex("title");
        int descriptionId = cursor.getColumnIndex("description");
        int datetimeId = cursor.getColumnIndex("datetime");
        String currentUser = getIntent().getStringExtra("CURRENT_USER");

        if(cursor.moveToNext()){
            do {
                int rowIdFromDB = cursor.getInt(rowId);
                String nameFromDB = cursor.getString(nameId);
                String titleFromDB = cursor.getString(titleId);
                String descriptionFromDB = cursor.getString(descriptionId);
                long dateTimeMillsFromDB = cursor.getLong(datetimeId);

                Date dateTime = new Date(dateTimeMillsFromDB);
                SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

                String dateTimeFromDB = dateTimeFormat.format(dateTime);
                String dateFromDB = dateTimeFromDB.substring(0,10);
                String timeFromDB = dateTimeFromDB.substring(11);

                if(nameFromDB.equals(currentUser)){
                    TodoItem todo = new TodoItem(titleFromDB, descriptionFromDB, dateFromDB, timeFromDB, nameFromDB, rowIdFromDB);
                    resultsList.add(0, todo);
                }
            }
            while (cursor.moveToNext());
        }
        return resultsList;
    }

    private void moveOn(int id, String title, String description, String date, String time){
        String currentUser = getIntent().getStringExtra("CURRENT_USER");
        Intent intent = new Intent(this, EditorActivity.class);
        intent.putExtra("ITEM_ID", id);
        intent.putExtra("ITEM_TITLE", title);
        intent.putExtra("ITEM_DESCRIPTION", description);
        intent.putExtra("ITEM_DATE", date);
        intent.putExtra("ITEM_TIME", time);
        intent.putExtra("ITEM_ID", id);
        intent.putExtra("FLAG", "updateScreen");
        intent.putExtra("CURRENT_USER", currentUser);
        startActivity(intent);
    }
}