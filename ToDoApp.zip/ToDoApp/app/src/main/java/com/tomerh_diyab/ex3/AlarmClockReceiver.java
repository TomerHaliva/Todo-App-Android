package com.tomerh_diyab.ex3;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class AlarmClockReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "my_channel";
    private static final CharSequence CHANNEL_NAME = "Main Channel";
    String username, title;

    @Override
    public void onReceive(Context context, Intent intent) {

        username = intent.getStringExtra("CURRENT_USER");
        title = intent.getStringExtra("ITEM_TITLE");
        NotificationManager notificationManager =

                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

// 2. Create Notification-Channel. ONLY for Android 8.0 (OREO API level 26) and higher.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            NotificationChannel notificationChannel = new NotificationChannel(

                    CHANNEL_ID, // Constant for Channel ID
                    CHANNEL_NAME, // Constant for Channel NAME
                    NotificationManager.IMPORTANCE_DEFAULT);

            notificationManager.createNotificationChannel(notificationChannel);
        }
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)

                .setSmallIcon(R.drawable.ic_about)
                .setContentTitle(username)
                .setContentText(title)
                .build();
        notificationManager.notify(1, notification);

        Log.d("debug", "ALARM!!!");
    }



}
