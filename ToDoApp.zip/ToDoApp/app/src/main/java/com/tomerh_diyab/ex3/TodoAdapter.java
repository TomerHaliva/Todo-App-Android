package com.tomerh_diyab.ex3;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class TodoAdapter extends ArrayAdapter<TodoItem> {

    public TodoAdapter(Activity context, ArrayList<TodoItem> arrayList){
        super(context, 0, arrayList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null)
            convertView = View.inflate(getContext(), R.layout.my_item, null);

        TodoItem currentTodoItem = getItem(position);

        TextView title = convertView.findViewById(R.id.itemTtile);
        title.setText(currentTodoItem.getTitle());

        TextView description = convertView.findViewById(R.id.itemDescription);
        description.setText(currentTodoItem.getDescription());

        TextView date = convertView.findViewById(R.id.itemDate);
        date.setText(currentTodoItem.getDate());

        TextView time = convertView.findViewById(R.id.itemTime);
        time.setText(currentTodoItem.getTime());

        return convertView;
    }

}
