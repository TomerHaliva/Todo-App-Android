package com.tomerh_diyab.ex3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class EditorActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton datePicker, timerPicker;
    private EditText inputDate, inputTime, inputTitle, inputDescription;
    private Button addTodoButton, updateTodoButton;
    private String currentUser, title, description;
    private TextView updateTitle;
    SQLiteDatabase TodosDB = LoginActivity.TodosDB;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;
    AlarmManager alarmManager;
    NotificationManager notificationManager;
    int year, month, day, hour, min, itemId;
    Calendar calendar;
    Date date, time, dateTime;
    long dateMills, timeMills, dateTimeMills;
    String timeString, dateString;

    private static final int ALARM_ID = 111;

    private String flag;
    private static int id;

    LinearLayout addScreen, updateScreen;
    ViewFlipper viewFlipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Toolbar actionBar = findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);

        addScreen = findViewById(R.id.addScreen);
        updateScreen = findViewById(R.id.updateScreen);

        viewFlipper = findViewById(R.id.viewsFlipper);

        flag = getIntent().getStringExtra("FLAG");



        if(flag.equals("updateScreen")){
            viewFlipper.setDisplayedChild(0);
            datePicker = findViewById(R.id.updateDatePicker);
            timerPicker = findViewById(R.id.updateTimePicker);
            inputDate = findViewById(R.id.updateInputDate);
            inputTime = findViewById(R.id.updateInputTime);
            inputTitle = findViewById(R.id.updateInputTitle);
            inputDescription = findViewById(R.id.updateInputDescription);
            inputTitle.setText(getIntent().getStringExtra("ITEM_TITLE"));
            inputDescription.setText(getIntent().getStringExtra("ITEM_DESCRIPTION"));
            inputDate.setText(getIntent().getStringExtra("ITEM_DATE"));
            inputTime.setText(getIntent().getStringExtra("ITEM_TIME"));
            itemId = getIntent().getIntExtra("ITEM_ID",-1);
            updateTitle = findViewById(R.id.updateTitle);
            updateTitle.setText(updateTitle.getText() + "" + itemId + ")");
        }

        else {
            viewFlipper.setDisplayedChild(1);
            datePicker = findViewById(R.id.DatePicker);
            timerPicker = findViewById(R.id.TimePicker);
            inputDate = findViewById(R.id.InputDate);
            inputTime = findViewById(R.id.InputTime);
            inputTitle = findViewById(R.id.InputTitle);
            inputDescription = findViewById(R.id.InputDescription);

        }

        currentUser = getIntent().getStringExtra("CURRENT_USER");
        id = getLastID() + 1;
        addTodoButton = findViewById(R.id.addTodoButton);
        addTodoButton.setOnClickListener(this);
        updateTodoButton= findViewById(R.id.updateTodoButton);
        updateTodoButton.setOnClickListener(this);

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);


                datePickerDialog = new DatePickerDialog(EditorActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                dateString = day + "/" + (month + 1) + "/" + year;
                                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                                try {
                                    date = format.parse(dateString);
                                    dateMills = date.getTime();
                                    inputDate.setText(dateString);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        timerPicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                hour = calendar.get(Calendar.HOUR_OF_DAY);
                min = calendar.get(Calendar.MINUTE);
                timePickerDialog = new TimePickerDialog(EditorActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                timeString = hourOfDay + ":" + minute;
                                SimpleDateFormat format = new SimpleDateFormat("HH:mm");
                                try {
                                    time = format.parse(timeString);
                                    timeMills = time.getTime() + 7200000;
                                    inputTime.setText(timeString);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        },hour,min,true);
                timePickerDialog.show();
            }
        });
    }

    private void goBack(){
        setAlarm();

        Intent intent = new Intent(this, ToDoListActivity.class);
        intent.putExtra("CURRENT_USER", currentUser);
        intent.putExtra("DATE_MILLS", dateMills);
        intent.putExtra("TIME_MILLS", timeMills);
        startActivity(intent);
    }

    private void setAlarm() {
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent alarmIntent = new Intent(this, AlarmClockReceiver.class);
        alarmIntent.putExtra("CURRENT_USER", currentUser);
        alarmIntent.putExtra("ITEM_TITLE",title);
        PendingIntent alarmPendingIntent = PendingIntent.getBroadcast(this, ALARM_ID, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        long triggerTimeMS = dateTimeMills;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            Calendar now = Calendar.getInstance();
            if(now.getTime().getTime() < dateTimeMills)
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMS, alarmPendingIntent);

        }

    }

    private boolean isInputNotEmpty(String inputTitle, String inputDescription, String inputDate, String inputTime){
        if(inputTitle.isEmpty() || inputDescription.isEmpty() || inputDate.isEmpty() || inputTime.isEmpty())
            return false;
        return true;
    }

    private int getLastID (){
        String sql = "SELECT * FROM todos";
        Cursor cursor = TodosDB.rawQuery(sql, null);
        int ID = cursor.getColumnIndex("_id");
        int result = 0;
        if (cursor.moveToFirst()){
            do {
                result = cursor.getInt(ID);
            }
            while (cursor.moveToNext());
        }
        return result;
    }


    @Override
    public void onClick(View v) {

        if(isInputNotEmpty(inputTitle.getText().toString(), inputDescription.getText().toString(), inputDate.getText().toString(), inputTime.getText().toString()) == false)
            Toast.makeText(EditorActivity.this, "One or more fields are empty", Toast.LENGTH_SHORT).show();
        else{
            dateTimeMills = dateMills + timeMills;
            dateTime = new Date(dateTimeMills);

            title = inputTitle.getText().toString();
            description = inputDescription.getText().toString();

            if(v.getId() == R.id.addTodoButton) {
                String addQuery = "INSERT INTO todos (_id, username, title, description, datetime) VALUES ('" + id + "', '" + currentUser + "', '" + title + "', '" + description + "', '" + dateTimeMills + "');";
                TodosDB.execSQL(addQuery);
                TodoItem item = new TodoItem(title, description, dateString, timeString, currentUser, id);
                ToDoListActivity.arrayList.add(item);
                id++;
                Toast.makeText(EditorActivity.this, "Todo was ADDED", Toast.LENGTH_SHORT).show();
                goBack();
            }
            else if(v.getId() == R.id.updateTodoButton) {

                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
                try {
                    date = dateFormat.parse(String.valueOf(inputDate.getText()));
                    time = timeFormat.parse(String.valueOf(inputTime.getText()));
                    dateMills = date.getTime();
                    timeMills = time.getTime() + 7200000;
                    dateTimeMills = dateMills + timeMills;
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                    String updateQuery = "UPDATE todos SET title = " + "'" + title + "' " + ", description = " + "'" + description + " '"
                            + ", datetime = " + "'" + dateTimeMills + "' " + "WHERE _id = " +"'" + itemId + "'";
                    TodosDB.execSQL(updateQuery);
                    Toast.makeText(EditorActivity.this, "Todo was UPDATED", Toast.LENGTH_SHORT).show();
                    goBack();
            }
        }
    }
}